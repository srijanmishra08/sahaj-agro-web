// GSAP Animation Script for Sahaj Agro
// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

document.addEventListener('DOMContentLoaded', () => {

    // --- 1. Navbar Logic (Scroll State & Mobile) ---
    const navbar = document.querySelector('.navbar');
    const logoDesktop = document.querySelector('.logo-desktop');
    const logoMobile = document.querySelector('.logo-mobile');
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Scroll Handler
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
            if (window.innerWidth > 768) {
                // Ensure correct logos show on desktop scroll
                logoDesktop.style.display = 'none';
                logoMobile.style.display = 'block';
            }
        } else {
            navbar.classList.remove('scrolled');
            if (window.innerWidth > 768) {
                logoDesktop.style.display = 'block';
                logoMobile.style.display = 'none';
            }
        }
    });

    // Mobile Menu
    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });

    navLinks.forEach(link => {
        link.addEventListener('click', () => navMenu.classList.remove('active'));
    });

    // --- 2. Animations (GSAP) ---

    // A. Hero Entrance
    const heroTl = gsap.timeline();
    heroTl.from(".hero-title", {
        y: 50,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        delay: 0.2
    })
        .from(".hero-subtitle", {
            y: 30,
            opacity: 0,
            duration: 0.8,
            ease: "power3.out"
        }, "-=0.6")
        .from(".hero-actions", {
            y: 20,
            opacity: 0,
            duration: 0.8
        }, "-=0.6")
        .from(".trust-badge", {
            y: 20,
            opacity: 0,
            duration: 0.8,
            stagger: 0.2
        }, "-=0.4");

    // B. Parallax Hero Image
    gsap.to(".hero-bg-wrapper", {
        yPercent: 30,
        ease: "none",
        scrollTrigger: {
            trigger: ".hero-section",
            start: "top top",
            end: "bottom top",
            scrub: true
        }
    });

    // C. Section Titles Reveal
    gsap.utils.toArray('.section-header, .about-text-col, .distribution-layout').forEach(section => {
        gsap.from(section.children, {
            scrollTrigger: {
                trigger: section,
                start: "top 85%",
                toggleActions: "play none none reverse"
            },
            y: 40,
            opacity: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: "power3.out"
        });
    });

    // D. About Stats & Values
    gsap.from(".stat-item", {
        scrollTrigger: {
            trigger: ".stats-row",
            start: "top 85%"
        },
        y: 30,
        opacity: 0,
        duration: 0.8,
        stagger: 0.2,
        ease: "back.out(1.7)"
    });

    gsap.from(".value-card", {
        scrollTrigger: {
            trigger: ".values-grid",
            start: "top 85%"
        },
        y: 40,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15
    });

    // E. Process Timeline
    gsap.from(".process-step", {
        scrollTrigger: {
            trigger: ".process-timeline",
            start: "top 80%"
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power2.out"
    });

    // F. Product Cards Stagger
    gsap.from(".product-card", {
        scrollTrigger: {
            trigger: ".products-grid",
            start: "top 80%"
        },
        y: 60,
        opacity: 0,
        duration: 0.8,
        stagger: 0.2,
        ease: "power2.out"
    });

    // G. Gallery Stagger
    gsap.from(".gallery-item", {
        scrollTrigger: {
            trigger: ".gallery-grid",
            start: "top 85%"
        },
        scale: 0.9,
        opacity: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: "power2.out"
    });

    // H. Footer Reveal
    gsap.from(".footer-col", {
        scrollTrigger: {
            trigger: ".site-footer",
            start: "top 90%"
        },
        y: 30,
        opacity: 0,
        duration: 0.8,
        stagger: 0.2
    });

    // --- 3. Filter Filtering Logic ---
    const filterBtns = document.querySelectorAll('.filter-btn');
    const productCards = document.querySelectorAll('.product-card');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Active Class
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-filter');

            productCards.forEach(card => {
                const category = card.getAttribute('data-category');

                if (filter === 'all' || filter === category) {
                    gsap.to(card, { autoAlpha: 1, scale: 1, display: 'block', duration: 0.4 });
                } else {
                    gsap.to(card, { autoAlpha: 0, scale: 0.95, display: 'none', duration: 0.4 });
                }
            });

            // Re-trigger ScrollTrigger refresh for layout changes
            ScrollTrigger.refresh();
        });
    });

});
